#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

python -m py_compile   "$ROOT/repo_payload/mrag/config.py"   "$ROOT/repo_payload/mrag/vlm.py"   "$ROOT/repo_payload/mrag/ask.py" \
  "$ROOT/repo_payload/benchmarks/mutcd150/v1/mutcd_benchmark_runner.py"

PYTHONPATH="$ROOT/repo_payload:${PYTHONPATH:-}"   python -m pytest -q "$ROOT/tests/test_vlm_response_adapter.py"

grep -q "api_max_tokens_anthropic: int = 16000"   "$ROOT/repo_payload/mrag/config.py"

grep -q "def _anthropic_client_for"   "$ROOT/repo_payload/mrag/vlm.py"

grep -q "reasoning_effort"   "$ROOT/repo_payload/mrag/vlm.py"

echo "Provider adapter patch verification passed."
