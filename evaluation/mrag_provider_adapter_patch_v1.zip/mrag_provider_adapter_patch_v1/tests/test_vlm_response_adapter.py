from __future__ import annotations

from types import SimpleNamespace
import sys
import types

import pytest

# The patch bundle intentionally contains only the three files that replace
# repository sources. Stub prompt_examples so vlm.py can be unit-tested in
# isolation without copying unrelated private repository files.
prompt_examples = types.ModuleType("mrag.prompt_examples")
prompt_examples.FEWSHOT_EXAMPLES = []
prompt_examples.format_example = lambda example: ""
sys.modules.setdefault("mrag.prompt_examples", prompt_examples)

from mrag.vlm import (
    VLM,
    VLMEmptyResponseError,
    VLMTruncatedResponseError,
)


def test_extract_plain_string():
    assert VLM._extract_text_content("  answer  ") == "answer"


def test_extract_openai_content_parts():
    content = [
        {"type": "reasoning", "text": "hidden"},
        {"type": "text", "text": "First"},
        {"type": "output_text", "text": "Second"},
    ]

    assert VLM._extract_text_content(content) == "First\nSecond"


def test_extract_anthropic_blocks():
    content = [
        SimpleNamespace(type="thinking", thinking="hidden"),
        SimpleNamespace(type="text", text="Final answer"),
    ]

    assert VLM._extract_text_content(content) == "Final answer"


def test_empty_openai_response_is_rejected():
    vlm = VLM(provider="api")
    response = SimpleNamespace(
        id="response-id",
        usage=None,
        choices=[
            SimpleNamespace(
                finish_reason="stop",
                message=SimpleNamespace(content=None),
            )
        ],
    )

    with pytest.raises(VLMEmptyResponseError):
        vlm._parse_openai_response(
            response,
            provider="gemini",
            model_id="gemini-3.5-flash",
            token_limit=4096,
            image_count=1,
            retry_number=0,
        )


def test_length_finish_reason_is_rejected():
    vlm = VLM(provider="api")
    response = SimpleNamespace(
        id="response-id",
        usage=None,
        choices=[
            SimpleNamespace(
                finish_reason="length",
                message=SimpleNamespace(content="Partial answer"),
            )
        ],
    )

    with pytest.raises(VLMTruncatedResponseError):
        vlm._parse_openai_response(
            response,
            provider="gemini",
            model_id="gemini-3.1-pro-preview",
            token_limit=8192,
            image_count=2,
            retry_number=0,
        )


def test_anthropic_max_tokens_is_rejected():
    vlm = VLM(provider="api")
    response = SimpleNamespace(
        id="message-id",
        usage=SimpleNamespace(
            input_tokens=100,
            output_tokens=16000,
        ),
        stop_reason="max_tokens",
        content=[
            SimpleNamespace(type="text", text="Partial"),
        ],
    )

    with pytest.raises(VLMTruncatedResponseError):
        vlm._parse_anthropic_response(
            response,
            model_id="claude-fable-5",
            token_limit=16000,
            image_count=3,
            retry_number=0,
        )
