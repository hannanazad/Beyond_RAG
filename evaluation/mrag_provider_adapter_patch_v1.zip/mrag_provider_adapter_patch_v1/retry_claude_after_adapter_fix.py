# Run only after both Claude smoke tests pass.
# Valid primary/retry answers should not be rerun.

SONNET_REMAINING_IDS = [
    "T017", "T020", "T023", "T026", "T033", "TB005",
    "M002", "M007", "M008", "M017", "M024",
]

FABLE_INVALID_IDS = [
    "F002", "F004", "F005", "F007", "F012", "F013", "F014",
    "F018", "F019", "F020", "F023", "M002", "M003", "M004",
    "M007", "M008", "M009", "M010", "M013", "M015", "M016",
    "M017", "M018", "M023", "M024", "T016", "T017", "T019",
    "T020", "T022", "T023", "T025", "T026", "T027", "T028",
    "T030", "T033", "TB003", "TB004", "TB005", "TB006", "TB007",
    "TB008", "TB009", "TB013", "TB016", "TB024",
]


def run_claude_retry(model_alias, question_ids, run_id):
    model_specs = [
        model
        for model in MODEL_REGISTRY
        if model.get("alias") == model_alias
    ]

    if not model_specs:
        raise ValueError(f"Enable {model_alias!r} in model_registry.json.")

    return run_benchmark(
        CFG=CFG,
        ask_fn=ask,
        questions_path=QUESTIONS_PATH,
        output_root=OUTPUT_ROOT,
        run_id=run_id,
        models=[model_specs[0]],
        prompt_style="fewshot",
        replicates=1,
        question_ids=question_ids,
        show_scores=True,
        show_text=True,
        max_attempts=5,
        retry_base_seconds=8.0,
        inter_request_seconds=2.0,
        seed=20260710,
        resume=True,
        rerun_errors=True,
        strict_benchmark_hash=True,
        strict_question_count=True,
        store_serialized_return=True,
        store_raw_debug=True,
        echo_answer_preview=True,
    )


# Uncomment only after the smoke test passes.
# sonnet_paths = run_claude_retry(
#     "balanced_claude",
#     SONNET_REMAINING_IDS,
#     "mutcd150_v8_balanced_claude_retry_native_01",
# )
#
# fable_paths = run_claude_retry(
#     "frontier_claude",
#     FABLE_INVALID_IDS,
#     "mutcd150_v9_frontier_claude_retry_native_01",
# )
