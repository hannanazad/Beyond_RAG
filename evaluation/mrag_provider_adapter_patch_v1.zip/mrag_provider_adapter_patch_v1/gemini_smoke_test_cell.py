# Provider-adapter smoke test.
# Run after pulling the patch and reloading mrag.config, mrag.vlm, and mrag.ask.

import json
import sys

from mrag.config import CFG
import mrag.vlm
import mrag.ask

print("VLM adapter:", mrag.vlm.__file__)
print("Ask module :", mrag.ask.__file__)

# Keep figure filtering fixed across answer-model families. This avoids a
# Claude/Gemini answer model also being used for the separate P2 filter call.
CFG.set_filter_model("flash_pinned")

SMOKE_IDS = [
    "T017",   # text
    "TB005",  # table
    "F005",   # figure
    "M008",   # mixed
    "M024",   # mixed
]

SMOKE_MODELS = [
    "frontier_gemini",
    "balanced_gemini",
    "fast_gemini",
]

for model_alias in SMOKE_MODELS:
    resolved = CFG.set_vlm_model(model_alias)
    run_id = f"adapter_smoke_{model_alias}"

    print("\n" + "=" * 72)
    print("Testing:", model_alias, "->", resolved)
    print("=" * 72)

    paths = run_benchmark(
        CFG=CFG,
        ask_fn=ask,
        questions_path=QUESTIONS_PATH,
        output_root=OUTPUT_ROOT,
        run_id=run_id,
        models=[
            {
                "alias": model_alias,
                "selector": model_alias,
                "provider": "gemini",
                "enabled": True,
            }
        ],
        prompt_style="fewshot",
        replicates=1,
        question_ids=SMOKE_IDS,
        show_scores=True,
        show_text=True,
        max_attempts=3,
        retry_base_seconds=8.0,
        inter_request_seconds=2.0,
        seed=20260710,
        resume=True,
        rerun_errors=True,
        strict_benchmark_hash=True,
        strict_question_count=True,
        store_serialized_return=True,
        store_raw_debug=True,
        echo_answer_preview=True,
    )

    validation = validate_run_outputs(
        paths["run_dir"],
        run_id,
    )

    print(json.dumps(validation, indent=2))

    assert validation["ok_records"] == len(SMOKE_IDS), (
        f"{model_alias} failed the adapter smoke test."
    )
