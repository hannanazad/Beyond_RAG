# MRAG provider adapter patch v1

## Confirmed root cause

The provider map is correct:

- Claude: `https://api.anthropic.com/v1/`
- Gemini: `https://generativelanguage.googleapis.com/v1beta/openai/`
- DashScope: Alibaba's OpenAI-compatible endpoint

The Claude failures were primarily caused by a provider-neutral output cap of
only `480` tokens. Claude Sonnet 5 and Claude Fable 5 use adaptive thinking,
and Anthropic applies `max_tokens` to **thinking plus visible response text**.
Complex visual questions could therefore consume the cap before a final answer
was emitted.

The old adapter also assumed that every provider returned a non-empty plain
string at `response.choices[0].message.content`.

## Will Gemini have the same problem?

Not identically. Gemini is already mapped to Google's official OpenAI-compatible
endpoint, whose standard examples return the final text through the OpenAI
message field.

However, Gemini 3 models also think dynamically. Leaving the cap at 480 would
still create a material truncation risk. The patch therefore gives each Gemini
tier a larger cap and explicitly sets OpenAI-compatible `reasoning_effort`:

- Gemini 3.1 Pro Preview: high, 8192 tokens
- Gemini 3.5 Flash: medium, 4096 tokens
- Gemini 3.1 Flash-Lite: low, 2048 tokens

## What the patch changes

1. Claude uses Anthropic's native Python SDK and Messages API.
2. Claude receives a 16,000-token cap, with one truncation retry up to 32,000.
3. Gemini continues to use Google's official OpenAI-compatible endpoint.
4. Gemini receives tier-specific reasoning effort and token caps.
5. String, list, dictionary, and typed text content blocks are parsed safely.
6. Empty answers are rejected.
7. `length` / `max_tokens` stop reasons are rejected and retried once.
8. Response metadata is recorded in `result.debug["vlm_response"]`.
9. Inline image payload size is checked before Gemini requests.
10. The figure filter uses safe provider-specific limits.
11. Hidden reasoning text is never used as the answer.
12. The bundle also installs benchmark runner v1.1.2, so notebook headings and figure captions cannot be accepted as answers.
13. Claude and Gemini smoke-test cells are included, along with selective retry lists for the invalid Sonnet and Fable records.

## Dependencies

```bash
python -m pip install -U openai anthropic pytest
```

## Verify locally

```bash
bash verify_patch.sh
```

## Publish to GitHub

```bash
bash publish_adapter_patch.sh   https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git   main
```

## Colab reload

After pulling the repository, restart the runtime or explicitly delete and
re-import these modules:

```python
import sys

for name in [
    "mrag.config",
    "mrag.vlm",
    "mrag.ask",
]:
    sys.modules.pop(name, None)

from mrag.config import CFG
from mrag.ask import init_pipeline, ask
```

Because `mrag.ask` keeps a process-wide `_pipeline` singleton, restarting the
runtime is the safest option after this patch.

## Gemini validation

Run `gemini_smoke_test_cell.py`. It tests five representative questions for
all three selected Gemini models. Do not begin a 150-question Gemini run until
all five questions produce:

- a non-empty answer,
- no VLM error,
- no truncation finish reason, and
- saved `vlm_response` metadata.

## Claude reruns

After the adapter is patched, rerun only the invalid Claude records, not the
valid records. Claude Fable and Sonnet should no longer be tested through the
480-token OpenAI-compatibility path.
