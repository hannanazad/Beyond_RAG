#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "Usage: bash publish_adapter_patch.sh <repository-url> [branch] [commit-message]"
  exit 1
fi

REPO_URL="$1"
BRANCH="${2:-main}"
COMMIT_MESSAGE="${3:-Harden Claude and Gemini multimodal response adapters}"

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TEMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TEMP_DIR"' EXIT

bash "$ROOT/verify_patch.sh"

git clone --branch "$BRANCH" "$REPO_URL" "$TEMP_DIR/repository"

mkdir -p "$TEMP_DIR/repository/mrag"
mkdir -p "$TEMP_DIR/repository/benchmarks/mutcd150/v1"

cp "$ROOT/repo_payload/mrag/config.py"    "$TEMP_DIR/repository/mrag/config.py"
cp "$ROOT/repo_payload/mrag/vlm.py"    "$TEMP_DIR/repository/mrag/vlm.py"
cp "$ROOT/repo_payload/mrag/ask.py"    "$TEMP_DIR/repository/mrag/ask.py"

cd "$TEMP_DIR/repository"

git add \
  mrag/config.py \
  mrag/vlm.py \
  mrag/ask.py \
  benchmarks/mutcd150/v1/mutcd_benchmark_runner.py

if git diff --cached --quiet; then
  echo "No changes to commit."
  exit 0
fi

git commit -m "$COMMIT_MESSAGE"
git push origin "$BRANCH"

echo "Provider adapter patch published successfully."
