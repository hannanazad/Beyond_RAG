from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--item-scores', required=True, help='Item-level score CSV')
    ap.add_argument('--gold-msdi', required=True)
    ap.add_argument('--output-dir', required=True)
    args = ap.parse_args()

    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    scores = pd.read_csv(args.item_scores)
    gold = [json.loads(line) for line in Path(args.gold_msdi).read_text(encoding='utf-8').splitlines() if line.strip()]
    meta = pd.DataFrame([{k: row.get(k) for k in (
        'question_id', 'answerability_subtype', 'original_difficulty',
        'revised_difficulty', 'sdi_total', 'localization_burden',
        'modality_integration_burden', 'reasoning_burden',
        'answer_composition_burden', 'normative_precision_burden',
    )} for row in gold])
    data = scores.merge(meta, on='question_id', how='left')
    data['api_success'] = ~data['answer'].fillna('').str.lstrip().str.startswith('(VLM error:')
    valid = data[data['api_success']].copy()

    summary = valid.groupby(['answerable', 'revised_difficulty', 'primary_modality']).agg(
        questions=('question_id', 'count'),
        correctness=('correctness', 'mean'),
        completeness=('completeness', 'mean'),
        faithfulness=('faithfulness', 'mean'),
        full_credit=('binary_full_correct', 'mean'),
        median_latency_ms=('latency_ms', 'median'),
    ).reset_index()
    data.to_csv(out / 'item_scores_with_msdi.csv', index=False)
    summary.to_csv(out / 'summary_by_answerability_difficulty_modality.csv', index=False)

    answerable = valid[valid['answerable'] == True]
    monotonicity = answerable.groupby('revised_difficulty').agg(
        n=('question_id', 'count'),
        full_credit=('binary_full_correct', 'mean'),
        correctness=('correctness', 'mean'),
        completeness=('completeness', 'mean'),
    ).reindex(['easy', 'medium', 'hard'])
    monotonicity.to_csv(out / 'answerable_monotonicity.csv')
    print(monotonicity)


if __name__ == '__main__':
    main()
