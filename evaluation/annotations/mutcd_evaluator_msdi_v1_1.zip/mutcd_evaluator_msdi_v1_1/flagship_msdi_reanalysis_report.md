# Flagship reanalysis using M-SDI v1.0

## Annotation revision

- Question texts: unchanged (`MUTCD-150-v1.0`)
- Gold annotation revision: `MUTCD-150-annotations-v1.1-MSDI`
- Difficulty scheme: `M-SDI-v1.0`
- Primary annotations: complete
- Independent second annotation: pending

## Revised distribution

- Easy: 66
- Medium: 62
- Hard: 22

Answerability is reported separately from difficulty. The 30 unanswerable items are no longer automatically classified as hard.

## Preliminary flagship monotonicity check

Provider/API failures are excluded. For answerable items, full-credit rates are:

- Easy: 73.6%
- Medium: 68.2%
- Hard: 55.6%

This is an ordinal decline in full-credit performance. It is preliminary because only one VLM has been evaluated. Item facility and IRT must wait until multiple models or human respondents are available.

## Required publication step

A second MUTCD-informed annotator should complete the blinded annotation sheet. Report quadratic weighted Cohen's kappa before adjudication and preserve both annotators' component scores.
