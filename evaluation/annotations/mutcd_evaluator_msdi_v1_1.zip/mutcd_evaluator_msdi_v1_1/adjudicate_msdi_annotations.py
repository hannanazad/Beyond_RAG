from __future__ import annotations

import argparse
from pathlib import Path
import pandas as pd

COMPONENTS = [
    "localization_burden",
    "modality_integration_burden",
    "reasoning_burden",
    "answer_composition_burden",
    "normative_precision_burden",
]


def classify(total: int) -> str:
    return "easy" if total <= 3 else "medium" if total <= 6 else "hard"


def weighted_kappa(a: pd.Series, b: pd.Series) -> float:
    from sklearn.metrics import cohen_kappa_score
    return float(cohen_kappa_score(a, b, weights="quadratic"))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--primary", required=True)
    parser.add_argument("--secondary", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    p = pd.read_csv(args.primary)
    s = pd.read_csv(args.secondary)
    rename = {
        f"secondary_{c}": f"secondary_{c}" for c in COMPONENTS
    }
    required = ["question_id", *rename]
    missing = [c for c in required if c not in s.columns]
    if missing:
        raise ValueError(f"Missing secondary columns: {missing}")

    merged = p.merge(s[required + ["secondary_notes"]], on="question_id", how="inner")
    for c in COMPONENTS:
        merged[f"secondary_{c}"] = pd.to_numeric(merged[f"secondary_{c}"], errors="raise").astype(int)
        if not merged[f"secondary_{c}"].isin([0, 1, 2]).all():
            raise ValueError(f"{c}: all scores must be 0, 1, or 2")

    merged["secondary_sdi_total"] = merged[[f"secondary_{c}" for c in COMPONENTS]].sum(axis=1)
    merged["secondary_difficulty"] = merged["secondary_sdi_total"].map(classify)

    print("Quadratic weighted Cohen kappa by component:")
    for c in COMPONENTS:
        print(f"  {c}: {weighted_kappa(merged[c], merged[f'secondary_{c}']):.3f}")
    print(f"  difficulty: {weighted_kappa(merged['revised_difficulty'], merged['secondary_difficulty']):.3f}")

    for c in COMPONENTS:
        merged[f"adjudicated_{c}"] = merged[c].where(
            merged[c] == merged[f"secondary_{c}"], pd.NA
        )
    merged["needs_adjudication"] = merged[[f"adjudicated_{c}" for c in COMPONENTS]].isna().any(axis=1)
    merged.to_csv(args.output, index=False)
    print(f"Wrote {args.output}; items needing adjudication: {int(merged['needs_adjudication'].sum())}")


if __name__ == "__main__":
    main()
