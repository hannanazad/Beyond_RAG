from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

ANSWERABILITY_SUBTYPE = {
    'T049': 'unsupported_precision', 'T050': 'unsupported_precision',
    'T051': 'false_presupposition', 'T052': 'false_presupposition',
    'T053': 'false_presupposition', 'T054': 'out_of_scope',
    'T055': 'out_of_scope', 'T056': 'out_of_scope',
    'T057': 'false_presupposition', 'T058': 'out_of_scope',
    'T059': 'contradicted_premise', 'T060': 'out_of_scope',
    'TB025': 'false_presupposition', 'TB026': 'false_presupposition',
    'TB027': 'unsupported_precision', 'TB028': 'out_of_scope',
    'TB029': 'out_of_scope', 'TB030': 'out_of_scope',
    'F025': 'unsupported_precision', 'F026': 'absent_information',
    'F027': 'unsupported_precision', 'F028': 'absent_information',
    'F029': 'unsupported_precision', 'F030': 'absent_information',
    'M025': 'out_of_scope', 'M026': 'out_of_scope',
    'M027': 'out_of_scope', 'M028': 'absent_information',
    'M029': 'out_of_scope', 'M030': 'out_of_scope',
}
BROAD_UNANSWERABLE = {
    'T049', 'T051', 'T052', 'T053', 'T054', 'T055', 'T056', 'T057',
    'T058', 'T060', 'TB025', 'TB029', 'M025', 'M026', 'M027', 'M028',
    'M029', 'M030',
}
SINGLE_STEP = {
    'normative_interpretation', 'visual_plus_rule', 'rule_plus_table',
    'visual_plus_normative', 'lookup_plus_interpretation', 'lookup_plus_rule',
    'threshold_plus_rule', 'lookup_plus_normative', 'lookup_plus_action',
    'visual_plus_timing_rule', 'definition_plus_table', 'visual_plus_definition',
    'rule_plus_visual_procedure', 'visual_table_lookup',
}
MULTI_STEP = {
    'exception_plus_lookup', 'cross_section_comparison', 'multi_condition',
    'calculation', 'sequence_plus_rule',
}
EXACT = re.compile(
    r'\b(minimum|maximum|exact|how many|what size|what distance|what color|'
    r'what percentage|which sign|what plaque|what code|threshold|rate|duration|'
    r'sequence|order|increment|feet|foot|mph|inches|years|milliseconds|dollar|'
    r'rgb|hex|pantone|candela|number of|what value|what values)\b', re.I,
)


def classify(total: int) -> str:
    if total <= 3:
        return 'easy'
    if total <= 6:
        return 'medium'
    return 'hard'


def annotate(row: dict) -> dict:
    qid = row['question_id']
    answerable = bool(row['answerable'])
    reason = row.get('reasoning_type', '')
    modality = row['primary_modality']
    pages = len(row.get('source_pdf_pages') or [])
    source_objects = sum(len(row.get(key) or []) for key in ('sections', 'tables', 'figures'))

    if answerable:
        L = 2 if reason == 'cross_section_comparison' or pages >= 3 or source_objects >= 3 else 1 if pages >= 2 or source_objects >= 2 else 0
    else:
        L = 2 if qid in BROAD_UNANSWERABLE else 0 if modality in {'table', 'figure'} and (row.get('tables') or row.get('figures')) else 1

    M = 0 if modality == 'text' else 1 if modality in {'table', 'figure'} else 2

    if answerable:
        R = 2 if reason in MULTI_STEP else 1 if reason in SINGLE_STEP else 0
    else:
        R = 2 if qid in BROAD_UNANSWERABLE else 1

    if answerable:
        count = len(row.get('required_answer_elements') or [])
        A = 0 if count <= 1 else 1 if count <= 3 else 2
    else:
        A = 0

    norm = str(row.get('normative_type') or '')
    if '/' in norm or reason in {'normative_interpretation', 'exception_plus_lookup', 'lookup_plus_normative', 'visual_plus_normative'}:
        N = 2
    elif norm in {'Standard', 'Guidance', 'Option'} or EXACT.search(row['question']) or modality in {'table', 'figure'}:
        N = 1
    else:
        N = 0

    total = L + M + R + A + N
    return {
        'difficulty_scheme': 'M-SDI-v1.0',
        'localization_burden': L,
        'modality_integration_burden': M,
        'reasoning_burden': R,
        'answer_composition_burden': A,
        'normative_precision_burden': N,
        'sdi_total': total,
        'revised_difficulty': classify(total),
        'answerability_subtype': None if answerable else ANSWERABILITY_SUBTYPE[qid],
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--input-gold-v1', required=True)
    ap.add_argument('--output-gold-v1-1', required=True)
    args = ap.parse_args()

    rows = [json.loads(line) for line in Path(args.input_gold_v1).read_text(encoding='utf-8').splitlines() if line.strip()]
    if len(rows) != 150:
        raise ValueError(f'Expected 150 rows, found {len(rows)}')

    output = []
    for row in rows:
        new = dict(row)
        new['schema_version'] = '1.1'
        new['annotation_revision'] = 'MUTCD-150-annotations-v1.1-MSDI'
        new['original_difficulty'] = row['difficulty']
        new.update(annotate(row))
        new['difficulty'] = new['revised_difficulty']
        output.append(new)

    with Path(args.output_gold_v1_1).open('w', encoding='utf-8', newline='\n') as f:
        for row in output:
            f.write(json.dumps(row, ensure_ascii=False) + '\n')


if __name__ == '__main__':
    main()
