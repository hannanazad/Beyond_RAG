# MUTCD evaluator annotation revision v1.1 (M-SDI)

This package is evaluator-only and must not be loaded by the RAG during inference.

It includes the revised 150-item gold file, complete primary M-SDI annotations, a blinded second-annotator sheet, the codebook, annotation-rebuild and agreement scripts, and revised flagship heatmaps.

The question texts and question-only SHA-256 are unchanged. The five provider-failed flagship questions still require a separate retry run.
