# MUTCD Heatmap Generator

This package reproduces the four heatmaps used in the MUTCD-150 model reports
and makes the plot styling configurable.

## What data are used?

The **heatmap plotting script reads CSV files only**.

It does not read:

- answer JSONL files,
- retrieval JSONL files,
- run manifests,
- gold-answer JSONL files, or
- evaluation-summary JSON files.

Those JSON/JSONL files were used **upstream** to calculate and audit the
metrics. The resulting aggregate CSVs were then used to draw the heatmaps.

The exact CSVs used for the challenger heatmaps are included under the four
separate `data/*/input/` directories.

## Directory layout

```text
mutcd_heatmap_generator/
├── generate_mutcd_heatmaps.py
├── heatmap_config.json
├── requirements.txt
├── README.md
└── data/
    ├── 01_answer_quality/
    │   ├── input/
    │   │   └── summary_by_modality.csv
    │   └── output/
    ├── 02_visual_retrieval/
    │   ├── input/
    │   │   └── visual_retrieval_summary.csv
    │   └── output/
    ├── 03_model_comparison/
    │   ├── input/
    │   │   └── model_comparison_metrics.csv
    │   └── output/
    └── 04_msdi_difficulty/
        ├── input/
        │   └── summary_by_answerability_difficulty.csv
        └── output/
```

Each heatmap has its own input and output directory.

## Installation

From the package directory:

```bash
python -m pip install -r requirements.txt
```

## Generate all heatmaps

```bash
python generate_mutcd_heatmaps.py --config heatmap_config.json
```

## Generate selected heatmaps

```bash
python generate_mutcd_heatmaps.py \
  --config heatmap_config.json \
  --only answer_quality visual_retrieval
```

Available heatmap names:

```text
answer_quality
visual_retrieval
model_comparison
msdi_difficulty
```

Add `--show` to display the charts while generating them:

```bash
python generate_mutcd_heatmaps.py \
  --config heatmap_config.json \
  --show
```

## Use another model's CSV files

Replace the CSV inside the appropriate `input/` directory, or edit the
`input_csv` path in `heatmap_config.json`.

For example:

```json
"input_csv": "data/01_answer_quality/input/my_model_summary.csv"
```

The CSV must retain the expected column names.

### Answer-quality CSV

Required columns:

```text
primary_modality
questions
correctness
completeness
faithfulness
citation
full_credit
```

### Visual-retrieval CSV

Required columns:

```text
primary_modality
questions
exact_crop_hit
page_hit_at_1
page_hit_at_3
page_hit_at_4
crop_precision
correctness
completeness
full_credit
```

### Model-comparison CSV

Required columns:

```text
Model
Correctness
Completeness
Faithfulness
Citation
Full credit
Normalized provisional score
```

`Normalized provisional score` is expected on a 0–100 scale and is multiplied
by `0.01` in the configuration before plotting.

### M-SDI CSV

Required columns:

```text
answerable
revised_difficulty
questions
correctness
completeness
full_credit
recall_at_5
```

## Customize style

All common styling is controlled in `global_style`:

```json
{
  "font_family": "DejaVu Sans",
  "font_size": 10,
  "title_size": 14,
  "title_weight": "normal",
  "title_style": "normal",
  "axis_label_size": 11,
  "tick_size": 10,
  "annotation_size": 10,
  "annotation_color": "black",
  "colormap": "viridis",
  "vmin": 0.0,
  "vmax": 1.0,
  "dpi": 220
}
```

Customizable elements include:

- colormap and color range,
- font family,
- general font size,
- title size, weight, and style,
- axis-label size and weight,
- tick size, weight, and rotation,
- annotation size, weight, style, and color,
- colorbar label, size, ticks, spacing, and visibility,
- figure dimensions,
- titles,
- axis labels,
- row ordering,
- metric ordering,
- displayed metric labels,
- output paths,
- DPI and image format,
- grid lines and plot spines.

Use `"annotation_color": "auto"` to switch automatically between black and
white text according to the cell background.

## Customize a single heatmap

Add values to its `style_overrides` object. For example:

```json
"style_overrides": {
  "colormap": "plasma",
  "title_size": 18,
  "annotation_size": 12,
  "colorbar": {
    "label": "Performance",
    "label_size": 12
  }
}
```

These settings affect only that heatmap.

## Change labels and titles

Every metric is declared as:

```json
{"column": "correctness", "label": "Correctness"}
```

Change `label` without changing the source CSV column name.

Titles and axis labels are controlled independently for each heatmap:

```json
"title": "My publication title",
"xlabel": "Evaluation dimension",
"ylabel": "Evidence category"
```

## Notes for publication

- The included defaults reproduce the visual structure of the earlier figures:
  Matplotlib, `viridis`, values constrained to 0–1, percentage annotations,
  separate figures, and 220 DPI.
- The plot code does not use Seaborn.
- Keep the same style configuration for every compared model to avoid visual
  bias.
- Use vector output by setting an output filename ending in `.pdf` or `.svg`
  and changing `output_format` if required by the journal.
