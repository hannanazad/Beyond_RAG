#!/usr/bin/env python3
"""
Generate publication-ready MUTCD benchmark heatmaps from aggregate CSV files.

The plotting stage reads CSV files only. It does not read the raw answer JSONL,
retrieval JSONL, manifest JSON, or evaluator gold JSONL. Those raw files are
needed upstream only when regenerating the aggregate CSV metrics.
"""

from __future__ import annotations

import argparse
import json
from copy import deepcopy
from pathlib import Path
from typing import Any

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


SUPPORTED_TYPES = {
    "modality_summary",
    "visual_summary",
    "model_comparison",
    "answerability_difficulty",
}


def deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """Recursively merge a style override into the global style."""
    result = deepcopy(base)

    for key, value in override.items():
        if (
            key in result
            and isinstance(result[key], dict)
            and isinstance(value, dict)
        ):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value

    return result


def parse_bool(value: Any) -> bool:
    """Normalize common Boolean encodings from CSV files."""
    if isinstance(value, bool):
        return value

    if isinstance(value, (int, np.integer)):
        return bool(value)

    normalized = str(value).strip().lower()

    if normalized in {"true", "1", "yes", "y"}:
        return True

    if normalized in {"false", "0", "no", "n"}:
        return False

    raise ValueError(f"Cannot interpret as Boolean: {value!r}")


def validate_columns(
    dataframe: pd.DataFrame,
    required_columns: list[str],
    csv_path: Path,
) -> None:
    missing = [
        column
        for column in required_columns
        if column not in dataframe.columns
    ]

    if missing:
        raise ValueError(
            f"{csv_path} is missing required columns: {missing}\n"
            f"Available columns: {list(dataframe.columns)}"
        )


def metric_columns(plot_config: dict[str, Any]) -> list[str]:
    return [
        metric["column"]
        for metric in plot_config["metrics"]
    ]


def metric_labels(plot_config: dict[str, Any]) -> list[str]:
    return [
        metric.get("label", metric["column"])
        for metric in plot_config["metrics"]
    ]


def apply_metric_scales(
    matrix: pd.DataFrame,
    plot_config: dict[str, Any],
) -> pd.DataFrame:
    result = matrix.copy()

    for metric in plot_config["metrics"]:
        column = metric["column"]
        scale = float(metric.get("scale", 1.0))
        offset = float(metric.get("offset", 0.0))

        result[column] = (
            pd.to_numeric(result[column], errors="coerce")
            * scale
            + offset
        )

    return result


def build_modality_matrix(
    dataframe: pd.DataFrame,
    plot_config: dict[str, Any],
    csv_path: Path,
) -> pd.DataFrame:
    required = [
        "primary_modality",
        *metric_columns(plot_config),
    ]

    if plot_config.get("include_question_count_in_row_label", True):
        required.append("questions")

    validate_columns(dataframe, required, csv_path)

    indexed = dataframe.set_index("primary_modality")
    row_order = plot_config.get(
        "row_order",
        list(indexed.index),
    )

    indexed = indexed.reindex(row_order)

    if indexed[metric_columns(plot_config)].isna().all(axis=1).any():
        missing_rows = list(
            indexed.index[
                indexed[metric_columns(plot_config)]
                .isna()
                .all(axis=1)
            ]
        )

        raise ValueError(
            f"{csv_path} does not contain requested row(s): {missing_rows}"
        )

    matrix = apply_metric_scales(
        indexed[metric_columns(plot_config)],
        plot_config,
    )

    if plot_config.get("include_question_count_in_row_label", True):
        row_labels = [
            (
                f"{str(modality).title()} "
                f"(n={int(indexed.loc[modality, 'questions'])})"
            )
            for modality in row_order
        ]
    else:
        custom_row_labels = plot_config.get("row_labels", {})
        row_labels = [
            custom_row_labels.get(
                str(modality),
                str(modality).title(),
            )
            for modality in row_order
        ]

    matrix.index = row_labels
    matrix.columns = metric_labels(plot_config)

    return matrix


def build_model_comparison_matrix(
    dataframe: pd.DataFrame,
    plot_config: dict[str, Any],
    csv_path: Path,
) -> pd.DataFrame:
    required = [
        "Model",
        *metric_columns(plot_config),
    ]

    validate_columns(dataframe, required, csv_path)

    indexed = dataframe.set_index("Model")
    row_order = plot_config.get(
        "row_order",
        list(indexed.index),
    )

    indexed = indexed.reindex(row_order)

    if indexed[metric_columns(plot_config)].isna().all(axis=1).any():
        missing_rows = list(
            indexed.index[
                indexed[metric_columns(plot_config)]
                .isna()
                .all(axis=1)
            ]
        )

        raise ValueError(
            f"{csv_path} does not contain requested model(s): {missing_rows}"
        )

    matrix = apply_metric_scales(
        indexed[metric_columns(plot_config)],
        plot_config,
    )

    matrix.columns = metric_labels(plot_config)

    custom_row_labels = plot_config.get("row_labels", {})
    matrix.index = [
        custom_row_labels.get(str(model), str(model))
        for model in row_order
    ]

    return matrix


def build_difficulty_matrix(
    dataframe: pd.DataFrame,
    plot_config: dict[str, Any],
    csv_path: Path,
) -> pd.DataFrame:
    required = [
        "answerable",
        "revised_difficulty",
        "questions",
        *metric_columns(plot_config),
    ]

    validate_columns(dataframe, required, csv_path)

    working = dataframe.copy()
    working["answerable"] = working["answerable"].map(parse_bool)
    working["revised_difficulty"] = (
        working["revised_difficulty"]
        .astype(str)
        .str.strip()
        .str.lower()
    )

    working = working.set_index(
        ["answerable", "revised_difficulty"]
    )

    row_order_config = plot_config.get("row_order", [])

    if row_order_config:
        row_order = [
            (
                parse_bool(item["answerable"]),
                str(item["difficulty"]).strip().lower(),
            )
            for item in row_order_config
        ]
    else:
        row_order = list(working.index)

    working = working.reindex(row_order)

    if working[metric_columns(plot_config)].isna().all(axis=1).any():
        missing_rows = list(
            working.index[
                working[metric_columns(plot_config)]
                .isna()
                .all(axis=1)
            ]
        )

        raise ValueError(
            f"{csv_path} does not contain requested difficulty row(s): "
            f"{missing_rows}"
        )

    matrix = apply_metric_scales(
        working[metric_columns(plot_config)],
        plot_config,
    )

    answerable_label = plot_config.get(
        "answerable_label",
        "Answerable",
    )
    unanswerable_label = plot_config.get(
        "unanswerable_label",
        "Unanswerable",
    )

    row_labels = []

    for answerable, difficulty in row_order:
        prefix = (
            answerable_label
            if answerable
            else unanswerable_label
        )

        count = int(
            working.loc[
                (answerable, difficulty),
                "questions",
            ]
        )

        row_labels.append(
            f"{prefix}—{difficulty.title()} (n={count})"
        )

    matrix.index = row_labels
    matrix.columns = metric_labels(plot_config)

    return matrix


def build_matrix(
    dataframe: pd.DataFrame,
    plot_config: dict[str, Any],
    csv_path: Path,
) -> pd.DataFrame:
    plot_type = plot_config["type"]

    if plot_type in {"modality_summary", "visual_summary"}:
        return build_modality_matrix(
            dataframe,
            plot_config,
            csv_path,
        )

    if plot_type == "model_comparison":
        return build_model_comparison_matrix(
            dataframe,
            plot_config,
            csv_path,
        )

    if plot_type == "answerability_difficulty":
        return build_difficulty_matrix(
            dataframe,
            plot_config,
            csv_path,
        )

    raise ValueError(
        f"Unsupported heatmap type {plot_type!r}. "
        f"Supported types: {sorted(SUPPORTED_TYPES)}"
    )


def annotation_color(
    style: dict[str, Any],
    image: mpl.image.AxesImage,
    value: float,
) -> str:
    configured = style.get("annotation_color", "black")

    if configured != "auto":
        return configured

    normalized = image.norm(value)
    red, green, blue, _ = image.cmap(normalized)

    luminance = (
        0.2126 * red
        + 0.7152 * green
        + 0.0722 * blue
    )

    return "black" if luminance > 0.55 else "white"


def render_heatmap(
    matrix: pd.DataFrame,
    plot_config: dict[str, Any],
    style: dict[str, Any],
    output_path: Path,
    show: bool,
) -> None:
    values = matrix.to_numpy(dtype=float)

    rc_parameters = {
        "font.family": style["font_family"],
        "font.size": style["font_size"],
        "figure.facecolor": style["figure_facecolor"],
        "axes.facecolor": style["axes_facecolor"],
        "axes.titlesize": style["title_size"],
        "axes.titleweight": style["title_weight"],
        "axes.labelsize": style["axis_label_size"],
        "xtick.labelsize": style["tick_size"],
        "ytick.labelsize": style["tick_size"],
    }

    with mpl.rc_context(rc_parameters):
        figure, axis = plt.subplots(
            figsize=tuple(plot_config["figure_size"])
        )

        masked_values = np.ma.masked_invalid(values)

        image = axis.imshow(
            masked_values,
            aspect=plot_config.get("aspect", "auto"),
            cmap=style["colormap"],
            vmin=float(style["vmin"]),
            vmax=float(style["vmax"]),
            interpolation=style["interpolation"],
        )

        axis.set_xticks(np.arange(matrix.shape[1]))
        axis.set_xticklabels(
            matrix.columns,
            rotation=float(style["x_tick_rotation"]),
            ha=style["x_tick_horizontal_alignment"],
            fontweight=style["tick_weight"],
        )

        axis.set_yticks(np.arange(matrix.shape[0]))
        axis.set_yticklabels(
            matrix.index,
            rotation=float(style["y_tick_rotation"]),
            fontweight=style["tick_weight"],
        )

        axis.set_title(
            plot_config.get("title", ""),
            fontsize=style["title_size"],
            fontweight=style["title_weight"],
            fontstyle=style["title_style"],
            pad=float(plot_config.get("title_pad", 10)),
        )

        axis.set_xlabel(
            plot_config.get("xlabel", ""),
            fontsize=style["axis_label_size"],
            fontweight=style["axis_label_weight"],
        )

        axis.set_ylabel(
            plot_config.get("ylabel", ""),
            fontsize=style["axis_label_size"],
            fontweight=style["axis_label_weight"],
        )

        if style.get("show_values", True):
            value_format = style.get("value_format", ".1%")
            nan_label = style.get("nan_label", "N/A")

            for row_index in range(matrix.shape[0]):
                for column_index in range(matrix.shape[1]):
                    value = values[row_index, column_index]

                    if np.isnan(value):
                        label = nan_label
                        text_color = style.get(
                            "nan_annotation_color",
                            style.get("annotation_color", "black"),
                        )
                    else:
                        label = format(value, value_format)
                        text_color = annotation_color(
                            style,
                            image,
                            value,
                        )

                    axis.text(
                        column_index,
                        row_index,
                        label,
                        ha="center",
                        va="center",
                        fontsize=style["annotation_size"],
                        fontweight=style["annotation_weight"],
                        fontstyle=style["annotation_style"],
                        color=text_color,
                    )

        if style.get("show_grid", False):
            axis.set_xticks(
                np.arange(-0.5, matrix.shape[1], 1),
                minor=True,
            )
            axis.set_yticks(
                np.arange(-0.5, matrix.shape[0], 1),
                minor=True,
            )
            axis.grid(
                which="minor",
                color=style["grid_color"],
                linewidth=float(style["grid_linewidth"]),
            )
            axis.tick_params(
                which="minor",
                bottom=False,
                left=False,
            )

        if not style.get("show_spines", True):
            for spine in axis.spines.values():
                spine.set_visible(False)

        colorbar_config = style.get("colorbar", {})

        if colorbar_config.get("enabled", True):
            colorbar = figure.colorbar(
                image,
                ax=axis,
                shrink=float(
                    colorbar_config.get("shrink", 1.0)
                ),
                pad=float(
                    colorbar_config.get("pad", 0.04)
                ),
            )

            colorbar.set_label(
                colorbar_config.get(
                    "label",
                    "Rate / normalized score",
                ),
                fontsize=int(
                    colorbar_config.get("label_size", 11)
                ),
                fontweight=colorbar_config.get(
                    "label_weight",
                    "normal",
                ),
            )

            colorbar.ax.tick_params(
                labelsize=int(
                    colorbar_config.get("tick_size", 10)
                )
            )

            if "ticks" in colorbar_config:
                colorbar.set_ticks(colorbar_config["ticks"])

            if "tick_labels" in colorbar_config:
                colorbar.set_ticklabels(
                    colorbar_config["tick_labels"]
                )

        output_path.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        figure.tight_layout()

        figure.savefig(
            output_path,
            dpi=int(style["dpi"]),
            bbox_inches=style["bbox_inches"],
            facecolor=style["figure_facecolor"],
        )

        if show:
            plt.show()

        plt.close(figure)


def generate_heatmap(
    package_root: Path,
    name: str,
    plot_config: dict[str, Any],
    global_style: dict[str, Any],
    show: bool,
) -> Path:
    if plot_config.get("type") not in SUPPORTED_TYPES:
        raise ValueError(
            f"Heatmap {name!r} has unsupported type "
            f"{plot_config.get('type')!r}."
        )

    input_path = (
        package_root
        / plot_config["input_csv"]
    ).resolve()

    output_path = (
        package_root
        / plot_config["output_file"]
    ).resolve()

    if not input_path.exists():
        raise FileNotFoundError(
            f"Input CSV for {name!r} was not found:\n"
            f"{input_path}"
        )

    dataframe = pd.read_csv(input_path)

    matrix = build_matrix(
        dataframe,
        plot_config,
        input_path,
    )

    style = deep_merge(
        global_style,
        plot_config.get("style_overrides", {}),
    )

    render_heatmap(
        matrix,
        plot_config,
        style,
        output_path,
        show,
    )

    matrix_output = plot_config.get(
        "processed_matrix_csv"
    )

    if matrix_output:
        matrix_path = (
            package_root
            / matrix_output
        ).resolve()

        matrix_path.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        matrix.to_csv(matrix_path)

    return output_path


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Generate one or more configurable MUTCD "
            "benchmark heatmaps from CSV files."
        )
    )

    parser.add_argument(
        "--config",
        default="heatmap_config.json",
        help="Path to the JSON configuration file.",
    )

    parser.add_argument(
        "--only",
        nargs="*",
        default=None,
        help=(
            "Optional heatmap names to generate. "
            "Example: --only answer_quality model_comparison"
        ),
    )

    parser.add_argument(
        "--show",
        action="store_true",
        help="Display each heatmap in addition to saving it.",
    )

    return parser.parse_args()


def main() -> None:
    arguments = parse_arguments()

    config_path = Path(arguments.config).resolve()

    if not config_path.exists():
        raise FileNotFoundError(
            f"Configuration file not found:\n{config_path}"
        )

    package_root = config_path.parent

    config = json.loads(
        config_path.read_text(encoding="utf-8")
    )

    global_style = config["global_style"]
    heatmaps = config["heatmaps"]

    selected = (
        set(arguments.only)
        if arguments.only
        else None
    )

    if selected:
        unknown = selected - set(heatmaps)

        if unknown:
            raise ValueError(
                f"Unknown heatmap name(s): {sorted(unknown)}\n"
                f"Available: {sorted(heatmaps)}"
            )

    generated_paths = []

    for name, plot_config in heatmaps.items():
        if not plot_config.get("enabled", True):
            continue

        if selected is not None and name not in selected:
            continue

        output_path = generate_heatmap(
            package_root=package_root,
            name=name,
            plot_config=plot_config,
            global_style=global_style,
            show=arguments.show,
        )

        generated_paths.append(output_path)

        print(f"Generated {name}: {output_path}")

    if not generated_paths:
        print("No heatmaps were enabled or selected.")


if __name__ == "__main__":
    main()
