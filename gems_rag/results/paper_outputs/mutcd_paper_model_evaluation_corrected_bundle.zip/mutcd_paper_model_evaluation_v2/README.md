# Corrected MUTCD paper evaluation

This revision fills the Qwen3-VL 235B retrieval submetrics from the raw 150-record output and recalculates its composite score.

Key correction:
- Retrieval: 19.35/25
- Overall normalized score: 86.73/100
- Cross-model rank: 9

All tables and figures in this directory use the corrected row.