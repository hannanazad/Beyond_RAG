# Claude Fable 5 complete analysis folder

This folder contains both adapter-fixed source runs, the canonical 150-question
merge, provenance, item-level scoring, aggregate summaries, and heatmaps.

## Canonical merged files

Use the files in `merged_outputs/`:

- `answers_mutcd150_v9_frontier_claude_merged_adapterfix_final.jsonl`
- `retrieval_mutcd150_v9_frontier_claude_merged_adapterfix_final.jsonl`
- `errors_mutcd150_v9_frontier_claude_merged_adapterfix_final.jsonl`
- `manifest_mutcd150_v9_frontier_claude_merged_adapterfix_final.json`
- `fable_merge_provenance.csv`

## Final provisional result

- Retrieval: 19.35/25
- Answer generation: 55.18/60
- Reliability currently measurable: 10.90/12
- Total: 85.43/97
- Normalized provisional score: 88.08/100
- Fully correct: 120/150
- Provider stop reasons: 150 end_turn
- Unresolved response-capture failures: 0
