# Claude Sonnet 5 complete output folder

This folder contains every uploaded Claude Sonnet 5 source run, the final
150-question canonical merge, provenance, and the completed MUTCD-150 analysis.

## Canonical files

Use the files in `merged_outputs/` for subsequent analysis:

- `answers_mutcd150_v8_balanced_claude_merged_final.jsonl`
- `retrieval_mutcd150_v8_balanced_claude_merged_final.jsonl`
- `errors_mutcd150_v8_balanced_claude_merged_final.jsonl`
- `manifest_mutcd150_v8_balanced_claude_merged_final.json`
- `sonnet_merge_provenance.csv`

## Final result

- Retrieval: 19.35/25
- Answer generation: 55.18/60
- Reliability currently measurable: 10.66/12
- Total: 85.18/97
- Normalized provisional score: 87.81/100
- Fully correct: 112/150
- No unresolved response-capture failures

## Merge rule

Adapter-fix retry 02 overrides adapter-fix retry 01, which overrides validated
usable records from retry 02 and retry 01, which override the primary run.
Every selected record is documented in `sonnet_merge_provenance.csv`.

The source archives and their extracted contents are retained for auditability.
