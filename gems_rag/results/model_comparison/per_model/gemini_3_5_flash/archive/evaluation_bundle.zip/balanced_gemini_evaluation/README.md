# Gemini 3.5 Flash complete analysis folder

This folder contains the primary run, the redundant three-question retry,
canonical outputs, item-level scores, aggregate summaries, comparison metrics,
and heatmaps.

## Canonical result

- Retrieval: 19.35/25
- Answer generation: 53.92/60
- Reliability currently measurable: 10.74/12
- Total: 84.00/97
- Normalized provisional score: 86.60/100
- Fully correct: 114/150
- Unresolved provider errors: 0

## Canonical source policy

All 150 canonical records come from the primary run. The retry archive is
retained for auditability, but no retry record replaces a valid primary answer.
See `canonical_outputs/redundant_retry_comparison.csv`.
