# Gemini 3.1 Pro Preview complete analysis folder

This folder contains the primary and retry source archives, extracted source
runs, canonical merged outputs, provenance, item scores, summaries, and
heatmaps.

## Canonical result

- Retrieval: 19.35/25
- Answer generation: 54.34/60
- Reliability currently measurable: 10.94/12
- Total: 84.63/97
- Normalized provisional score: 87.25/100
- Fully correct: 114/150
- Primary records used: 136
- Retry records used: 14
- Unresolved provider errors: 0

Use the files under `canonical_outputs/` for subsequent analysis.
