MRAG Ablation Results — A6_no_reranker

Contents:
  runs_A6_no_reranker.jsonl   Raw RAG outputs from the ablation sweep.
                             One JSON row per question with:
                               qa_id, question, answer, chunks_used,
                               figures_used, pages_used, debug, latency_s, error
  meta.json                  Ablation config + timestamp + counters + git sha.

This zip is data collection only. No scoring, no metrics, no interpretation
was applied by the harness that produced it.

Hand this file to GPT-5.6 with the MUTCD-150 rubric prompt for judgment.

Ablation: A6_no_reranker
Description: Swap reranker for NoOp.
Generated: 2026-07-25T21:30:37
VLM alias: frontier_claude
Prompt style: fewshot
Records ok: 150
Records errored: 0
Total questions: 150
